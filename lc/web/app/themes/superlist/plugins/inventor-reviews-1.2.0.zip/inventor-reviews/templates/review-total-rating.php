<div class="inventor-reviews-total-rating">
    <?php $total_rating = get_post_meta( $listing_id, INVENTOR_REVIEWS_TOTAL_RATING_META, true ); ?>
    <?php $total_rating = empty ( $total_rating ) ? 0 : $total_rating; ?>
    <?php $reviews_count = get_comment_count( $listing_id ); ?>

    <i class="fa fa-star"></i>
    <?php
    echo sprintf( _n(
        '<strong>%.2f / 5 </strong> from <a href="#listing-detail-section-reviews">%d review</a>',
        '<strong>%.2f / 5 </strong> from <a href="#listing-detail-section-reviews">%d reviews</a>',
        $reviews_count['approved'],
        'inventor-reviews'
    ), $total_rating, $reviews_count['approved'] );
    ?>

<script type="application/ld+json">
{
    "@context" : "http://schema.org",
    "@type" : "Product",
    "name":"<?php echo get_the_title(); ?>",
    "url":"<?php echo get_permalink(); ?>",
    "aggregateRating": {
        "@type":"AggregateRating",
        "worstRating":"0",
        "bestRating":"5",
        "ratingValue":"<?php echo $total_rating; ?>",
        "reviewCount":"<?php echo $reviews_count['approved']; ?>"
    }
}
</script>

</div><!-- /.inventor-reviews-total-rating -->